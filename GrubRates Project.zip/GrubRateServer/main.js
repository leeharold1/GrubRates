/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Main server dependencies
const express = require('express');
const cors = require('cors');
const bodyParser = require("body-parser");
const server = express();
const port = 3000;

//BodyParser
server.use(bodyParser.json());
server.use(bodyParser.urlencoded({extended: true}));

//Cors
server.use(cors());

//MySQL dependencies
const mysql = require('mysql');

//Server start
server.listen(3000, function () {
    console.log('Server running on port: 3000');
});

//Connecting to database
const conn = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'grubrate'
});

conn.connect((err) => {
    if (err)
        throw err;
    console.log('Successfully connected to the database!');
});

//Create reviews table
var createReviews = "CREATE TABLE IF NOT EXISTS reviews(name VARCHAR(255) PRIMARY KEY, restaurant VARCHAR(255), location VARCHAR(255), review VARCHAR(255), rating VARCHAR(255));";

conn.query(createReviews, function (err) {
    if (err)
        throw err;
    console.log("Reviews Table Created");
});

//Create users table
var createUsers = "CREATE TABLE IF NOT EXISTS users(username VARCHAR(255) PRIMARY KEY, password VARCHAR(255));";

conn.query(createUsers, function (err) {
    if (err)
        throw err;
    console.log("Users Table Created");
});

//Reviews and users array
var reviews = {};
var users = {};

//Create review function
server.post("/create", function (request, reply) {
    //Variable to check connection to server and post was succesful.
    var verify = false;

    if (request.body) {
        if (!reviews[request.body.name]) {
            verify = true;
            
            var queryIns = "INSERT INTO reviews (name, restaurant, location, review, rating) VALUES(" + "'" + request.body.name + "'" + "," + "'" + request.body.restaurant + "'" + "," + "'" + request.body.location + "'" + "," + "'" + request.body.review + "'" + "," + request.body.rating + ");";
            conn.query(queryIns, function (err) {
                if (err)
                    throw err;
                console.log("Review entered to database.");
            });
        }

        if (verify) {
            reply.send("Review Successfully Created!");
        } else {
            reply.send("Failed to create Review!");
        }
    }
});

//Retrieve function(reviews page)
server.get("/review", function (request, reply) {
    conn.query("SELECT * FROM reviews;", function (err, result) {
        if (err)
            throw err;
        JSON.stringify(result);
        for (var i = 0; i < result.length; i++) {
            reviews [result[i].name] = {
                "name": result[i].name,
                "restaurant": result[i].restaurant,
                "location": result[i].location,
                "review": result[i].review,
                "rating": result[i].rating
            };
        }
        reply.json(reviews);
    });
});

//Delete function
server.post("/review", (request, reply) => {
    var verify = false;

    if (request.body) {
        if (reviews[request.body.name]) {
            delete reviews[request.body.name];

            conn.query("DELETE FROM reviews Where name = " + "'" + request.body.name + "';", function (err, result) {
                if (err)
                    throw err;
            });

            verify = true;
        }
    }

    if (verify) {
        reply.send("Review has succesfully been deleted!");
    } else {
        reply.send("Please enter a valid username to delete");
    }
});

//Update function
server.post("/update", (request, reply) => {
    var verify = false;

    if (request.body) {
        if (reviews[request.body.name]) {
            var queryUpdate = "UPDATE reviews SET restaurant = '" + request.body.restaurant + "'," + "location = '" + request.body.location + "'," + "review = '" + request.body.review + "'," + "rating = '" + request.body.rating + "'" + "WHERE name = '" + request.body.name + "';";
            conn.query(queryUpdate, function (err) {
                if (err) throw err;
            });
            
            verify = true;
            
        }
    }
    if (verify) {
        reply.send("Review successfully updated!");
    }       
    else {
        reply.send("Error updating review");
    }
});

//Create user function(Home page)
server.post("/index", function (request, reply) {
    // variable to check connection to server and post was succesful.
    var verify = false;

    if (request.body) {
        if (!users[request.body.username]) { 
            verify = true;
            
            var queryIns = "INSERT INTO users (username, password) VALUES(" + "'" + request.body.username + "'" + "," + "'" + request.body.password + "'" + ");";
            conn.query(queryIns, function (err) {
                if (err)
                    throw err;
                console.log("Username and password entered to database.");
            });
        }

        if (verify) {
            reply.send("Username and Password Successfully Created!");
        } else {
            reply.send("Failed to create Username and Password!");
        }
    }
});

//Login function(Sign In page) 
server.get("/login", function (request, reply) {
    conn.query("SELECT * FROM users;", function (err, result) {
        if (err)
            throw err;
        JSON.stringify(result);
        
        for (var i = 0; i < result.length; i++) {
            users [result[i].username] = {
                "username": result[i].username,
                "password": result[i].password
            };
        }
        reply.json(users);
    });
});