/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

const urlIndex = "http://localhost:3000/index";
const urlReview = "http://localhost:3000/review";
const urlUpdate = "http://localhost:3000/update";
const urlCreate = "http://localhost:3000/create";
const urlLogin = "http://localhost:3000/login";