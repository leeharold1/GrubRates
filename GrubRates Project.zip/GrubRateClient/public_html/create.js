/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var createReview = function () {
    var name = document.getElementById("nameTxt").value;
    var restaurant = document.getElementById("restTxt").value;
    var location = document.getElementById("locationTxt").value;
    var reviewDesc = document.getElementById("reviewTxt").value;
    var rating = document.getElementById("rating").value;
    if (name === "" || restaurant === "" || location === "" || reviewDesc === "") {
        alert("Error creating review. Text fields cannot be empty");
    } else {
        const http = new XMLHttpRequest();
        const review = {
            "name": name,
            "restaurant": restaurant,
            "location": location,
            "review": reviewDesc,
            "rating": rating

        };


        http.open("Post", urlCreate);
        http.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        http.send(JSON.stringify(review));

        http.onreadystatechange = function () {
            if (http.readyState === XMLHttpRequest.DONE && http.status === 200) {
                alert(http.responseText);
            }
        };
    }


};
