/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

var createUser = function () {
    var cUser = document.getElementById("username").value;
    var cPass = document.getElementById("password").value;
    const http = new XMLHttpRequest();
    const user = {
        "username": cUser,
        "password": cPass
    }
    if (cUser === "" || cPass === "") {
        alert("Error creating user. Text fields cannot be empty")
    } else {

        http.open("POST", urlIndex);
        http.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
        http.send(JSON.stringify(user));

        http.onreadystatechange = function () {
            if (http.readyState === XMLHttpRequest.DONE && http.status === 200) {
                alert(http.responseText);
                console.log(JSON.stringify(user));
            }
        };
    }
    ;
};

var login = function () {
    var logUsername = document.getElementById("logUsername").value;
    var logPass = document.getElementById("logPassword").value;
    const http = new XMLHttpRequest();
    http.open("GET", urlLogin);
    http.send();
    if (logUsername === "" || logPass === "") {
        alert("Error. Text fields cannot be blank!")
    } else {
        http.onreadystatechange = function () {
            if (http.readyState === XMLHttpRequest.DONE && http.status === 200) {
                users = JSON.parse(http.responseText);
                var verify = false;
                Object.keys(users).forEach(function (username) {
                    user = users[username];
                    if (logUsername === user.username && logPass === user.password) {
                        window.location.href = "create.html"; // Reference: https://stackoverflow.com/questions/4426184/how-to-go-from-one-page-to-another-page-using-javascript
                        verify = false;
                    }
                    else {
                        verify = true;
                    }
                    
                });
               /* if (verify) {
                    alert("Invalid username or password");
                }*/
            }

        };
    }
};

